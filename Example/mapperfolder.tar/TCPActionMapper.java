package sutInterface.tcp;

import sutInterface.tcp.init.InitOracle;

public class TCPActionMapper extends TCPMapper{
	public TCPActionMapper(InitOracle oracle) {
		super(oracle);
	}
}
